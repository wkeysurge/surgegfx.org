
// Simple snow canvas
const canvas = document.getElementById('snow');
const ctx = canvas.getContext('2d');
let w = canvas.width = innerWidth;
let h = canvas.height = innerHeight;
let flakes = [];
const FL = Math.max(80, Math.floor((w*h)/15000));
function rand(a,b){return Math.random()*(b-a)+a;}
function init(){flakes=[]; for(let i=0;i<FL;i++){flakes.push({x:rand(0,w),y:rand(0,h),r:rand(1,4),d:rand(0.5,2),velY:rand(0.3,1.2),alpha:rand(0.4,0.95)});}}
function draw(){ctx.clearRect(0,0,w,h); for(const f of flakes){ctx.beginPath(); ctx.fillStyle='rgba(255,255,255,'+f.alpha+')'; ctx.ellipse(f.x,f.y,f.r*1.2,f.r*0.8,0,0,Math.PI*2); ctx.fill(); f.y+=f.velY; f.x+=Math.sin(Date.now()/1000 + f.d)*0.3; if(f.y>h+10){f.y=-10; f.x=Math.random()*w;} } requestAnimationFrame(draw);}
addEventListener('resize',()=>{w=canvas.width=innerWidth; h=canvas.height=innerHeight; init();});
init(); draw();

// Add decorative lights nodes
const lights = document.querySelector('.lights');
if(lights){
  for(let i=0;i<6;i++){
    const s = document.createElement('span');
    lights.appendChild(s);
  }
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(a=>{ a.addEventListener('click', e=>{ const href=a.getAttribute('href'); if(href.length>1){ e.preventDefault(); document.querySelector(href).scrollIntoView({behavior:'smooth',block:'start'}); } }); });

// Mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.nav');
navToggle?.addEventListener('click', ()=>{
  if(nav.style.display==='flex'){ nav.style.display='none'; } else { nav.style.display='flex'; nav.style.flexDirection='column'; nav.style.gap='12px'; }
});
